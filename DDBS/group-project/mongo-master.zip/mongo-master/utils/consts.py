#!/usr/bin/python3
# -*- coding: utf-8 -*-
# @Time    : 2019-04-28 16:45
# @Author  : Gahon
# @Email   : Gahon1995@gmail.com


# class Region:
#     bj = 'Beijing'
#     hk = 'Hong Kong'


# class DBMS:
#     all = [Region.bj, Region.hk]
#     DBMS1 = Region.bj
#     DBMS2 = Region.hk


# class Category:
#     science = 'science'
#     technology = 'technology'
