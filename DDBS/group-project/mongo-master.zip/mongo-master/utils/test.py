
with open('test.dat', 'r') as f:
    for line in f:
        data = line.rstrip('\n')


