#!/usr/bin/python3
# -*- coding: utf-8 -*-
# @Time    : 2019-05-05 12:49
# @Author  : Gahon
# @Email   : Gahon1995@gmail.com

from utils.func import singleton
from service.user_service import UserService
