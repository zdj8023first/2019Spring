# 姓名： 赵东杰
# 学号： P18206023
# 手机： 13121595665
# 邮箱： zdj8023first@163.com
# 学校： 华北计算技术研究所


报告基于并行计算最新论文，论文信息如下

Shaolong Chen, Miquel Angel Senar,
Exploring efficient data parallelism for genome read mapping on multicore and manycore architectures,
Parallel Computing,
Volume 87,
2019,
Pages 11-24,
ISSN 0167-8191,
https://doi.org/10.1016/j.parco.2019.04.014.

对论文中的主要要点进行了分析总结，详细介绍了并行计算在人类基因组对比分析中的应用。
